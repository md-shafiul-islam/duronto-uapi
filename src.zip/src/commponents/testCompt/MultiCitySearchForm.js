import React, { useState } from "react";
import { Formik, Form, FieldArray } from "formik";
import { Row, Col, Button } from "react-bootstrap";
import TravellersAndClass from "./travellersAndClass";
import AutoSearchSuggestionList from "./AutoSearchSuggestionList";
import SingleDatePicker from "./SingleDatePicker";
import { addDays } from "date-fns";

const MultiCitySearchForm = (params) => {
  const [pDate, setPDate] = useState(new Date());
  const [nextDate, setNextDate] = useState(new Date());
  const [lastDate, setLastDate] = useState(new Date());
  const [newItem, setNewItem] = useState({
    from: "",
    to: "",
    depTime: new Date(),
  });

  const getNextItem = (passDetails) => {
    console.log("Passenger Details: ", passDetails);
    let lastIdx = passDetails.length > 0 ? passDetails.length - 1 : 0;
    let lastItem = passDetails[lastIdx];
    let item = {
      from: "",
      to: "",
      depTime: new Date(),
    };

    console.log("last Item ", lastItem);
    let nDate = new Date(lastItem.depTime);
    nDate = addDays(nDate, 1);

    item.from = lastItem.to;
    item.depTime = nDate;

    console.log("Item Data: ", item);

    if (item === undefined || item === null) {
      return item;
    }
    setNewItem(item);
    return item;
  };
  return (
    <React.Fragment>
      <Formik
        initialValues={params.multyInitValue}
        onSubmit={(values, actions) => {
          params.getSearchValueAndSubmit(values);
        }}
      >
        {(props) => (
          <Form>
            <React.Fragment>
              <Row className="mp-0">
                <Col md={12}>
                  <FieldArray name="passDetails">
                    {({ push, remove }) => (
                      <React.Fragment>
                        {props.values.passDetails &&
                          props.values.passDetails.map((item, indx) => (
                            <Row className="air-search" key={`trip-${indx}`}>
                              {console.log(
                                "Multy City: index",
                                indx,
                                " And Item: ",
                                item
                              )}
                              <Col md={6} className="no-margin-padding">
                                <Row className="no-margin-padding">
                                  <Col md={6} className="no-margin-padding">
                                    <AutoSearchSuggestionList
                                      preSetItem={item.from}
                                      title="From"
                                      suggestions={params.sugList}
                                      name={`passDetails[${indx}].from`}
                                      id={`passDetails[${indx}].from`}
                                      getSelectedData={(value) => {
                                        props.setFieldValue(
                                          `passDetails[${indx}].from`,
                                          value
                                        );
                                      }}
                                    />
                                  </Col>
                                  <Col md={6} className="no-margin-padding">
                                    <AutoSearchSuggestionList
                                      title="TO"
                                      preSetItem={item.to}
                                      suggestions={params.sugList}
                                      name={`passDetails[${indx}].to`}
                                      id={`passDetails[${indx}].to`}
                                      getSelectedData={(value) => {
                                        props.setFieldValue(
                                          `passDetails[${indx}].to`,
                                          value
                                        );
                                      }}
                                    />
                                  </Col>
                                </Row>
                              </Col>
                              <Col md={2} className="no-margin-padding">
                                <SingleDatePicker
                                  preSetDate={item.depTime}
                                  getDate={(item) => {
                                    props.setFieldValue(
                                      `passDetails[${indx}].depTime`,
                                      item
                                    );

                                    setLastDate(item);
                                  }}
                                />
                              </Col>

                              <Col md={3} className="no-margin-padding">
                                {indx === 0 ? (
                                  <TravellersAndClass
                                    getAllRangeData={(
                                      adults,
                                      child,
                                      infants,
                                      cabinClass
                                    ) => {
                                      /*this.setAllRangeData(
                                        adults,
                                        child,
                                        infants,
                                        cabinClass
                                      );*/

                                      props.setFieldValue(
                                        `traveler.ADT`,
                                        adults
                                      );
                                      props.setFieldValue(
                                        `traveler.CHD`,
                                        child
                                      );
                                      props.setFieldValue(
                                        `traveler.INF`,
                                        infants
                                      );
                                      props.setFieldValue(
                                        `traveler.cabClass`,
                                        cabinClass
                                      );
                                    }}
                                  />
                                ) : (
                                  <Row>
                                    <Col md={8} className="ptop">
                                      <a
                                        className=" btn btn-block btn-outline-primary btn-xs"
                                        href="javascript:void(0);"
                                        onClick={() => {
                                          push(
                                            getNextItem(
                                              props.values.passDetails
                                            )
                                          );
                                        }}
                                      >
                                        ADD ANOTHER CITY
                                      </a>
                                    </Col>
                                    {indx > 1 ? (
                                      <Col md={4} className="ptop">
                                        <span
                                          onClick={() => remove(indx)}
                                          className=" btn btn-block btn-outline-danger btn-xs"
                                        >
                                          <i class="fas fa-backspace"></i>
                                        </span>
                                      </Col>
                                    ) : (
                                      ""
                                    )}
                                  </Row>
                                )}
                              </Col>
                            </Row>
                          ))}
                      </React.Fragment>
                    )}
                  </FieldArray>
                </Col>
              </Row>
            </React.Fragment>

            <Row>
              <Col md={{ span: 2, offset: 5 }}>
                <Button type="submit" className="btn btn-block btn-primary">
                  Search
                </Button>
              </Col>
            </Row>
          </Form>
        )}
      </Formik>
    </React.Fragment>
  );
};

export default MultiCitySearchForm;
